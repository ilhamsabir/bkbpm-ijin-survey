<div class="footer">
  <div class="footer-inner">
    <div class="footer-content">
      <span class="bigger-120">
        BKBPM Perijinan Survey / PKL / Penelitian &copy; 2017
      </span>

    </div>
  </div>
</div>

<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
  <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
</a>
</div><!-- /.main-container -->

<!-- basic scripts -->

<!--[if !IE]> -->
<script src="<?php echo base_url();?>assets-app/js/jquery-2.1.4.min.js"></script>
<!-- page specific plugin scripts -->
<script src="<?php echo base_url();?>assets-app/js/ace-extra.min.js"></script>
<script src="<?php echo base_url();?>assets-app/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>assets-app/js/jquery-additional-methods.min.js"></script>
<script src="<?php echo base_url();?>assets-app/js/bootbox.js"></script>
<script src="<?php echo base_url();?>assets-app/js/jquery.maskedinput.min.js"></script>
<script src="<?php echo base_url();?>assets-app/js/select2.min.js"></script>
<script type="text/javascript">
if('ontouchstart' in document.documentElement) document.write("<script src='assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>
<script src="<?php echo base_url();?>assets-app/js/bootstrap.min.js"></script>
<!-- page specific plugin scripts -->
<!-- ace scripts -->
<script src="<?php echo base_url();?>assets-app/js/ace-elements.min.js"></script>
<script src="<?php echo base_url();?>assets-app/js/ace.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets-app/js/jquery-ui.js"></script>


<script src="<?php echo base_url();?>admin-assets/js/plugins/icheck/jquery.icheck.js"></script>
<script src="<?php echo base_url();?>admin-assets/js/plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="<?php echo base_url();?>admin-assets/js/plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>admin-assets/js/plugins/fileupload/bootstrap-fileupload.js"></script>

<script type="text/javascript" src="<?php echo base_url('admin-assets/js/jquery.printPage.js')?>"></script>
<script src="<?php echo base_url();?>admin-assets/js/bootstrap-wizard.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>admin-assets/smart/js/jquery.smartWizard-2.0.min.js"></script>

<!-- Custom JS -->

<script src="<?php echo base_url();?>assets-app/form-wiz.js"></script>
<script src="<?php echo base_url();?>assets-app/custom-validasi.js"></script>
<script src="<?php echo base_url();?>assets-app/custom.js"></script>
<script src="<?php echo base_url();?>assets-app/main.js"></script>




</body>
</html>
