<footer class="footer">

  <div class="container">

    <div class="row">

      <div class="col-sm-3">

        <h4>BKBPM Kota Bandung</h4>

        <br>

        <p>Perizinan Online v(1.0).</p>

        <hr>

        <p>&copy; 2015.</p>

      </div> <!-- /.col -->







    </div> <!-- /.row -->

  </div> <!-- /.container -->

</footer>

  <script src="//cdn.ckeditor.com/4.5.6/full/ckeditor.js"></script>

  <script src="<?php echo base_url();?>admin-assets/js/libs/jquery-1.10.1.min.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/libs/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/libs/bootstrap.min.js"></script>

    <script src="<?php echo base_url();?>admin-assets/js/moment-with-locales.js"></script>
  <!--[if lt IE 9]>
  <script src="./js/libs/excanvas.compiled.js"></script>
  <![endif]-->

  <!-- Plugin JS -->
  <script src="<?php echo base_url();?>admin-assets/js/plugins/icheck/jquery.icheck.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/plugins/select2/select2.js"></script>


  <!-- App JS -->
  <script src="<?php echo base_url();?>admin-assets/js/target-admin.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/plugins/icheck/jquery.icheck.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/plugins/select2/select2.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/plugins/datepicker/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/plugins/timepicker/bootstrap-timepicker.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/plugins/simplecolorpicker/jquery.simplecolorpicker.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/plugins/autosize/jquery.autosize.min.js"></script>
  <script src="<?php echo base_url();?>admin-assets/js/plugins/fileupload/bootstrap-fileupload.js"></script>

  <!-- Plugin JS -->
  <script src="<?php echo base_url();?>admin-assets/js/demos/form-extended.js"></script>



</body>
</html>
