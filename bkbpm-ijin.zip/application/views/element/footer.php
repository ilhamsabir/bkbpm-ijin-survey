<!-- Footer -->
<footer>
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; Perijinan BKBPM Kota Bandung 2016</p>
        </div>
    </div>
</footer>

</div>
<!-- /.container -->

<script src="<?php echo base_url();?>assets/js/jquery-1.12.4.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/validator/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/validator/dist/js/bootstrapValidator.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/daftar.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/pilih-tanggal.js"></script>


</body>
</html>
